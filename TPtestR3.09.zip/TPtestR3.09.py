#Bonjour Monsieur voici mon examen R309, seul la partie graphique est fonctionnel, je n'ai pas reussi a faire la partie socket.


import sys
import socket
import threading
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QVBoxLayout, QPushButton, QLineEdit, QLabel, QWidget
)
from PyQt6.QtCore import Qt


class Serveur(QMainWindow):
    
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Serveur")
        self.setGeometry(100, 100, 300, 200)


        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        self.layout = QVBoxLayout(self.central_widget)
        self.ip_label = QLabel("Adresse IP du serveur :")
        self.layout.addWidget(self.ip_label)
        self.ip_input = QLineEdit("127.0.0.1")
        self.layout.addWidget(self.ip_input)
        self.port_label = QLabel("Port :")
        self.layout.addWidget(self.port_label)
        self.port_input = QLineEdit("4200")
        self.layout.addWidget(self.port_input)
        self.clients_label = QLabel("Nombre de client maximum :")
        self.layout.addWidget(self.clients_label)
        self.clients_input = QLineEdit("5")
        self.layout.addWidget(self.clients_input)
        self.boutonconnexion = QPushButton("Démarrer le serveur")
        self.boutonconnexion.clicked.connect(self.toggle_server)
        self.layout.addWidget(self.boutonconnexion)
        self.lab_mess = QLabel("")
        self.layout.addWidget(self.lab_mess)
        self.boutonconnexion.clicked.connect(self.__actionOk)

#    def start_server(self):
#
 #       ip = self.ip_input.text()
  #      port = int(self.port_input.text())
   #     self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    #    self.server_socket.bind((ip, port))
     #   self.server_socket.listen(1)
      #  self.running = True
       # self.accept_thread = threading.Thread(target=self.accept_connection)
        #self.accept_thread.start()
    
   # def accept_connection(self):
    #    self.client_socket, = self.server_socket.accept()
        


    def toggle_server(self):
        if self.boutonconnexion.text() == "Démarrer le serveur":
            self.boutonconnexion.setText("Arrêter le serveur")
        else:
            self.boutonconnexion.setText("Démarrer le serveur")
    
    def __actionOk(self):
        self.lab_mess.setText(f"Bonjour")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = Serveur()
    window.show()
    sys.exit(app.exec())


#https://github.com/AuxaneLans/R3.09